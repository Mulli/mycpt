<?php
define ('MBO_UPLOAD_XL_DELET', 'mbo-xl-report'); // directory in uload dir for xl files
  
add_shortcode("delet2xl", 'mbo_delet2xl'); // show all meta data for cpt
$mbo_acflist = array();

function mbo_delet2xl($atts, $content = null ) {
	global $mbo_acflist;

    $a = shortcode_atts( array(
        'acf-json-group' => 'group_5fdbb577d6bd3',
        'href'  =>  '#'
    ), $atts );

	$debug = 0;

    // 1. generate map from json
	$filename = WP_PLUGIN_DIR . '/mycpt/acf-json/' . $a['acf-json-group'] . '.json';
	if ($debug) error_log('mbo_delet2xl json file name'.$filename);
	$str = file_get_contents( $filename);

	//	Now decode the JSON using json_decode():
	$json = json_decode($str, true); // decode the 
    // 2. utilities
	// uload directory, file name, escape comma...

	// 3. map all post types (plan) to large array
    // 4. generate the excel file
	$acfmap = array();
    $acfmap = genAcfMap($json['fields'][0], $acfmap);
	
	//if ($debug) error_log('acfmap:'. print_r($mbo_acflist, true)); // GOOD for debug
	$map2xl = array(); // Heaader names of excel file
	$name2field = array(); // mapping names to field type
	$out = "";
	$i = 0;
	$xl = 0;
	foreach ($mbo_acflist as $item){
		if ($item['type'] == "message" || $item['type'] == "tab" || $item['name'] == "" || $item['name'] == []) continue;
		$repeater_data = $item['type'] != "repeater" ?  "" : $item['min'] . ":" . $item['max'] ;

		$line = "<td>" . $i++ . "</td>" . "<td>" . $xl .':' . itoAA($xl). "</td>" 
				. "<td>". $item['label'] . "</td>"
				. "<td style='direction:ltr'>" . $item['name'] . "</td>" 
				. "<td style='direction:ltr'>" . $item['type'] . "</td>"
				. "<td>" . $repeater_data . "</td>";
		$out .= "<tr>". $line . "</tr>";

		$v = esc_xl_comma($item['label']);
		if (isset($name2field[$item['name']])) // DEBUG
			error_log('REWRITE in name2field. current='. print_r($name2field[$item['name']], true) . 'newvalue='. 
				print_r(array('type'=> $item['type'], 'col' => $xl, 'col_id' => $item['name'], 'label' => $v), true));

		$name2field[$item['name']] = array('type'=> $item['type'], 'col' => $xl, 'col_id' => $item['name'], 'label' => $v);
		$map2xl[$xl] = $v; //$item['label']; // $item['name']; // $v
		if ($debug) error_log('map2xl col='. $xl . ' label = '. $v . '  name='. $item['name']);
		$xl += 1;

		if ($item['type'] == "repeater"){ // handle ONLY SIMPLE children no groups/repeater grandchildren
			$repeatermap2xl = array();
			$res = do_repeater($item, ($i-1), $xl);
			$out .= $res[0];
			for ($k = 0; $k < count($res[1]); $k++){
				$v = $res[1][$k]; // name id
				// take until first underscore & add name (id) of field
				//$name2col_xl[$item['name'] . '_' . $v] = $xl; // in repeater sub fields must have parent name
				$name2field[$item['name'] . '_' . $v] = array('type'=> $item['type'], 'col' => $xl, 'col_id' => $item['name'] . '_' . $v, 'label' => $res[2][$k]);
				$map2xl[$xl] = $res[2][$k]; // $item['label']; // $v;
				if ($debug) error_log('map2xl col='. $xl . ' label = '. $res[2][$k] . '  name='. $item['name'] . '_' . $v);
				$xl += 1;
			}
		}
	}
	if (count($map2xl) != count($name2field))
		error_log('ERROR SIZE OF map2xl = '. count($map2xl) . ' name2field='. count($name2field));
	// get files data
	$filesdata = get_files_data('digma_WorkplansDefs');
	// if ($debug) error_log('p data='. print_r($filesdata, true));

	$res_array = locate_fields($filesdata, $name2field); // foreach field in data locate column

	$xl_filename = get_delet_xl_filename();

	$newmap = implode (",", $map2xl);
	$newmap_comma = substr_count($newmap, ',');
	file_put_contents ( $xl_filename , "\xEF\xBB\xBF" . $newmap . "\n");
	//file_put_contents ( $xl_filename.'.csv' , "\xEF\xBB\xBF" . $newmap . "\n");	

	for($i=0; $i < count($res_array) ; $i++){
		$l = implode (",", $res_array[$i]); // all inner items wrapped in "" with single " replaced by ''
		file_put_contents ( $xl_filename , $l . "\n", FILE_APPEND);
		//file_put_contents ( $xl_filename.'.csv' , $l . "\n", FILE_APPEND);
	}

	//file_put_contents ( 'helloxl.xls' , "\xEF\xBB\xBF" . $newmap);
	// testing
	//if (count($map2xl) != count($name2index))
	$testsr = count($map2xl) != count($name2field)? "<p> Ooops mapxl/header=" . count($map2xl) . "   name2index= ". count($name2field) . "</p>"
				: '<p>סה"כ עמודות אקסל: ' . count($map2xl) . "</p>";
	///// DEBUG  if ($debug) error_log('name2field='. print_r($name2field, true));

	return $testsr . "<table><tbody>" . xl_get_header() . $out . "</tbody></table>";// . "<p>" . print_r($name2field, true) . "</p>";
}

// foreach field in data locate column
function locate_fields($filesdata, $name2field){
	$debug = 0;
	$i = 0;
	$res_array = array();
	foreach($filesdata as $f){
		$outline = map_cpt2xl($f, $name2field);
		$res_array[$i]= $outline;
		if ($debug) error_log('locate columns INPUT'. print_r($f, true));
		if ($debug) error_log('locate columns OUTPUT'. print_r($outline, true));
		//if ($i > 2) break;
		$i += 1;
	}
	return $res_array;
}
// map cpt values to excel sheel columns
// note that cpt holds some values not all columns are filled
function map_cpt2xl($f, $name2field){
	$outline = array();
	
	//error_log('name2field SIZE='. count($name2field));
	for ($j = 0; $j < count($name2field); $j++){
		$outline[$j] = "";
	}

	foreach ($f as $fi){
		if (is_array($fi)){
			foreach ($fi as $k => $v){

				if ($k == "" | $k == []) continue;
				if (!isset($name2field[$k]))
					error_log('======= column not found ======== name2field k='. $k);
				else {
				 	// DEBUG - error_log('map_cpt2xl k='. print_r($k, true) . '   v=' . print_r($v, true) . ' name2field='. print_r($name2field[$k], true));
					$ftype = $name2field[$k]['type'];

					//if (($k == "wp_solution_area_other_goal" || $k == "wp_solution_area_other_table")) // ($name2field[$k]['col'] == 62 || $name2field[$k]['col'] == 63) &&
					//	error_log("hi");

					if ($ftype == "number" || $ftype == "text" || $ftype == "textarea"|| $ftype == "select" || $ftype == "radio" || $ftype == "date_picker")
						$outline[$name2field[$k]['col']] =  esc_xl_comma($v); //esc_xl_comma('"'.$v.'"') ;

					else if ($ftype == "checkbox" ) { // handle multiple values (serialized??)
						if (isset($v) && is_array($v)){
							if (empty($v)) $outline[$name2field[$k]['col']] = "";
							else $outline[$name2field[$k]['col']] = esc_xl_comma(implode(' | ', $v)) ; // 'checkbox';
						}else $outline[$name2field[$k]['col']] = "";
						//if (($name2field[$k]['col'] == 66 || $name2field[$k]['col'] == 198) && !empty($v))
						//	error_log('TEST CHECKBOX map_cpt2xl k='. print_r($k, true) . '   v=' . print_r($v, true) . ' name2field='. print_r($name2field[$k], true));
					}
					else if ($ftype == "repeater" ) { // get array and put in correct columns
						$jcount = 1;
						if (isset($v) && is_array($v)){
							for ($i = 0; $i < count($v); $i++){
								if (isset($v[$i]) && is_array($v[$i])){
									$vi = $v[$i];
									foreach ($vi as $kk => $vv)
										$outline[($name2field[$k]['col']+$jcount++)] = esc_xl_comma($vv); // esc_xl_comma('"'. $vv . '"');
								}
							}
						} else if (isset($v) && !is_array($v) && !empty($v))
							error_log('========= repeater not handled' . $ftype . '  NOT AN ARRAY! MIGHT BE EMPTY?? see description above!! :-) ');
						else $outline[($name2field[$k]['col']+$jcount++)] = ""; // empty array - ok
 					} 
					else if ($ftype == "group" )
						$outline[$name2field[$k]['col']] = ""; // $name2field[$k]['col'] . 'label:'.$name2field[$k]['label'];
					else error_log('========= type not handled' . $ftype . '  see description above!! :-) ');
				}
			}
		}
	}
	//if ($debug) error_log('outline SIZE='. count($outline));
	
	return $outline;
}
function get_files_data($post_type){
	$progs = get_posts( array('post_type' => $post_type, 'posts_per_page' => -1, 'status' => 'publish') );
    if (count($progs) < 1)
        return "No post of type= ". $post_type . " found";
	$arr = array();
	foreach ($progs as $prog){
		$arr[$prog->ID] = get_field('workplans_plan_3', $prog->ID);
	}
	return $arr;
}
function do_repeater($item, $index, $xl){
	$out = "";
	$i = 0; 
	$repeatermap2xllable = array();
	$repeatermap2xlname = array();
	for ($j = 0; $j < $item['max'] ; $j++){
		$subf = $item['sub_fields'];
		foreach ($subf as $sf){
			$line = "<td>" . $index . "(". $j . ")" . "</td>" . "<td>" . ($xl+$i).':' . itoAA($xl+$i) . "</td>"
			. "<td>" . $j. '_' . $sf['label'] . "</td>"
			. "<td style='direction:ltr'>" . $j. '_' . $sf['name'] . "</td>" 
			. "<td style='direction:ltr'> " . $sf['type'] . "</td>"
			. "<td>" . "#". $j . "</td>";
			$out .= "<tr>". $line . "</tr>";
			$repeatermap2xllable[$i] = $j . '_' . $sf['label'];
			$repeatermap2xlname[$i] = $j . '_' . $sf['name'];
			$i += 1;
		}
	}
	return [$out, $repeatermap2xlname, $repeatermap2xllable];
}
// csv escape comma
function esc_xl_comma($text){
	if (!isset($text) || $text == "") return "";
	$ntext = str_replace('"', "''", $text);
	//return '"' . str_replace(",", ';', $text) . '"';
	return '"' . $ntext . '"';
}
// excel column presentation
function itoAA($n){
	for($r = ""; $n >= 0; $n = intval($n / 26) - 1)
		$r = chr($n%26 + 0x41) . $r;
	return $r;
}

function xl_get_header(){
	$line = "<td>" . '#' . "</td>" . "<td>" . 'מיפוי' . "</td>" 
				. "<td>". 'שם השדה' . "</td>"
				. "<td style='direction:ltr'>" . 'מזהה בתוכנה' . "</td>" 
				. "<td style='direction:ltr'>" . 'סוג' . "</td>"
				. "<td>" . 'הערות' . "</td>";
	return "<tr style='font-weight:bold'>". $line . "</tr>";
}

function genAcfMap($start, $acfMap){
	global $mbo_acflist;
	if ($start['type'] == "tab" || $start['type'] == "message"){ // ignore
		$mbo_acflist[$start['key']] = $start;
		return $acfMap;
	}
	// handle inner node in tree
	if ($start['type'] == "group" /*|| $start['type'] == "repeater"*/){ // treat repeater as regular field
		$mbo_acflist[$start['key']] = $start;
		if (isset($start['sub_fields'])){
			for ($i=0; $i < count($start['sub_fields']); $i++)               
				genAcfMap($start['sub_fields'][$i], $acfMap);
		} else return $acfMap;
	}
	// handle simple leaf in tree
	if ($start['name'] == ""){
		error_log('Empty name = ' . $start);
		return $acfMap;
	}

	$acfMap[$start['key']] = $start;
	$acfMap[$start['name']] = $start;
	if ($start['type'] != 'group') // collect before - not after
		$mbo_acflist[$start['key']] = $start;
	//error_log('RECURS=<pre style="direction:ltr">' . print_r($acfMap, true) . '</pre>');
	return $acfMap;
}


function get_delet_xl_filename(){
	$upload_dir = delet_xl_uploadir(MBO_UPLOAD_XL_DELET);
    return $upload_dir . "/" . gen_delet_xl_fname();
}

// Generates xl file name based on creation time
function gen_delet_xl_fname(){
    date_default_timezone_set('Asia/Jerusalem');

    $today = getdate();
    $fname = sprintf("DeletXlReport%4d-%02d-%02d-%02d%02d%02d.xls", $today['year'], $today['mon'], $today['mday'], 
                                $today['hours'], $today['minutes'], $today['seconds']);
    return $fname;
}
// verify directory exists
function delet_xl_uploadir($dir) {
    $upload = wp_upload_dir();
    $upload_dir = $upload['basedir'];
    $upload_dir = $upload_dir . '/'. $dir;
    if (! is_dir($upload_dir)) {
        mkdir( $upload_dir, 0755 );
    }
    return $upload_dir;
}

?>